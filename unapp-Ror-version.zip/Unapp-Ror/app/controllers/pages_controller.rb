class PagesController < ApplicationController
  def about
  end

  def blog
  end

  def contact
  end

  def services
  end

  def work
  end

  def work_grid
  end

  def work_grid_without_text
  end
end
