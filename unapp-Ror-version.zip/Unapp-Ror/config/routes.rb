Rails.application.routes.draw do


  root 'home#index'
  get 'home/index', to: 'home#index'

  get 'pages/about'

  get 'pages/blog'

  get 'pages/contact'

  get 'pages/services'

  get 'pages/work'

  get 'pages/work-grid'

  get 'pages/work-grid-without-text'
   
end
